import tensorflow as tf
# Define initial values for variables
initial_w = tf.random.normal([3, 2], stddev=0.1)
initial_b = tf.zeros([2])

# Create variables with initial values
w = tf.Variable(initial_w, name='weights')
b = tf.Variable(initial_b, name='biases')

# Example usage of the variables
input_data = tf.random.normal([5, 3])
output = tf.matmul(input_data, w) + b

print("Output shape:", output.shape)

n_input=784
n_output=10